package com.build4all.notifications.repository;

import com.build4all.notifications.domain.FrontAppNotification;
import com.build4all.notifications.domain.NotificationActorType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FrontAppNotificationRepository extends JpaRepository<FrontAppNotification, Long> {

    List<FrontAppNotification> findByOwnerProjectLinkIdAndReceiverTypeAndReceiverIdOrderByCreatedAtDesc(
            Long ownerProjectLinkId,
            NotificationActorType receiverType,
            Long receiverId
    );

    int countByOwnerProjectLinkIdAndReceiverTypeAndReceiverIdAndIsReadFalse(
            Long ownerProjectLinkId,
            NotificationActorType receiverType,
            Long receiverId
    );
}