package com.build4all.app.service;

public class CiManifestPoller {

}
