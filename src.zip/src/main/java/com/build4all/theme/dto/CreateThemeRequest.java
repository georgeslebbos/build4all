// src/main/java/com/build4all/theme/dto/CreateThemeRequest.java
package com.build4all.theme.dto;

import java.util.Map;

public class CreateThemeRequest {

    private String name;                // required
    private Boolean isActive;           // optional
    private Map<String, Object> values; // the theme object sent from UI (key by key)

    public String getName() {
        return name;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public Map<String, Object> getValues() {
        return values;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIsActive(Boolean active) {
        isActive = active;
    }

    public void setValues(Map<String, Object> values) {
        this.values = values;
    }
}
