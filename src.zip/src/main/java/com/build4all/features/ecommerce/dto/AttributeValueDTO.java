package com.build4all.features.ecommerce.dto;

public class AttributeValueDTO {
    private String code;   // "brand"
    private String value;  // "Apple"

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
}
