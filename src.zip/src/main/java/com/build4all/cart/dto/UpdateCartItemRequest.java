package com.build4all.cart.dto;

public class UpdateCartItemRequest {
    private int quantity;

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}
