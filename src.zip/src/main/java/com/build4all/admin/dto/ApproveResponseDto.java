package com.build4all.admin.dto;

public record ApproveResponseDto(Long adminId, Long projectId, String slug) {}
