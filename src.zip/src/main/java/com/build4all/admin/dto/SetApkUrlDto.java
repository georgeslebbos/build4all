package com.build4all.admin.dto;
public record SetApkUrlDto(String apkUrl) {}
