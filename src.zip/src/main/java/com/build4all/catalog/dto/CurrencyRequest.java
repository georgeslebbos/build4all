package com.build4all.catalog.dto;

public class CurrencyRequest {
    private String currencyType;

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }
}
