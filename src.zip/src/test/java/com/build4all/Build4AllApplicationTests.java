package com.build4all;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Build4AllApplicationTests {

	@Test
	void contextLoads() {
	}

}
